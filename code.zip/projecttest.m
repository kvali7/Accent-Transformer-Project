clc;
clearvars -except TrainedClassifierVowCon TrainedClassifierVow TrainedClassifierComp mvowcon svowcon mvow svow mcomp scomp

accent = "brit";

cons = ["b","d","g","j","l","m","n","ng","r","th_voiced","v","w","y","z","zh"];
vows = ["a_cat","ai_snail", "air_chair", "ar_car" , "aw_law", "e_egg", "ee_bee", "er_ladder", "i_england", "i_spider", "o_swan" , "oa_boat" , "oi_coin" , "oo_book" , "oo_moon" , "or_four" , "ow_cow" , "u_mug" , "u_uniform"];




filename = 'C:\Users\Kourosh Vali\Box\eec201\data\untitledfolder\oa_boat\her.mp3';


filenamesplit = regexp(filename, filesep, 'split');


[audioIn, fs] = audioread(filename);

audioIn = resample(audioIn, 16000,fs);
fs = 16000;
sound(audioIn,fs)
if size(audioIn,2) >1
    error ('the sample is stereo convert it to mono') 
end


% twoStart = 110e3;
twoStart = 1;
% twoStop = 135e3;
twoStop = length(audioIn);
audioIn = audioIn(twoStart:twoStop);
timeVector = linspace((twoStart/fs),(twoStop/fs),numel(audioIn));
deltatime = (twoStop/fs) - (twoStart/fs);



pD = audiopluginexample.SpeechPitchDetector;
[~,pitch] = process(pD,audioIn);

ov =0;
tf = 30e-3;
[~, mfccact] = calcMFCC(audioIn,fs,ov,tf);
numcoef = floor(deltatime/tf);

figure(10);
subplot(3,1,1);
plot(timeVector,audioIn);
xlim([(twoStart/fs) (twoStop/fs)])
ylabel('Amplitude')
xlabel('Time (s)')
title(char(filenamesplit(end)))

subplot(3,1,2)
plot(timeVector,pitch,'*')
xlim([(twoStart/fs) (twoStop/fs)])
ylabel('Pitch (Hz)')
xlabel('Time (s)');
title('Pitch Contour');


% normalize
% mfcc = rmmissing(mfcc);
% m = mean(rmmissing(mfcc));
% s = std(rmmissing(mfcc));

% mfccact = (mfccact-mvowcon)./svowcon;
% mfccact = (mfccact-mvow)./svow;
mfccact = (mfccact-mcomp)./scomp;


numcoef = floor(deltatime/tf);

subplot(3,1,3)
i=0;
for n=1:numcoef
    
    plot ((1+i)/13:1/13:(13+i)/13,mfccact(n,:))
    i= 13+i;
    hold on
    xlabel('Timeframes and 13 mfcc frequency bins');
    line([i/13 i/13], [-3 ,3])
    
end


title('MFCC features');
ylabel('amplitude normalized')
xlim([0 numcoef])




%  predictedLabels = string(predict(TrainedClassifierVowCon,rmmissing(mfccact)))
%  predictedLabels = string(predict(TrainedClassifierVow,rmmissing(mfccact)))
 predictedLabels = string(predict(TrainedClassifierComp,rmmissing(mfccact)))

totalValidCoefs = size(predictedLabels,1)
[predictedLabel, freq] = mode(categorical(predictedLabels))
match = freq/totalValidCoefs*100





sig = ~isnan(sum(mfccact,2));
out = repmat("-",[length(sig) 1]);
j=1;
for i=1:length(sig)
   if sig(i) 
       if ismember(predictedLabels(j),cons)
            out(i) = "-";
       else
           out(i) = predictedLabels(j);
       end
       
       
       j=j+1;
   end
    
end
out








vowcount =0;
adrvow = [];
vow=[];
i=1;
finaladr_list = [];
vowtype_list=[];
confvow_list=[];
vowstarttime_list = [];
vowendtime_list = [];

while(1)
    while (out(i)~="-")     

        out(i);
        vow = [vow; out(i)];
        adrvow = [adrvow; i];
        i=i+1;

    end
    if ~isempty(vow)
       [finaladr, vowtype, confvow]=smoothen(adrvow, vow);
       
       if finaladr
           
%           the actual identified vowel and its start and end time

          vowcount = vowcount+1;
          vowstarttime =(finaladr(1)-1) * 30e-3;
          vowendtime = (finaladr(end))*30e-3;
          
          finaladr_list = [finaladr_list, finaladr];
          vowtype_list = [vowtype_list, vowtype];
          confvow_list = [confvow_list, confvow];
          vowstarttime_list = [vowstarttime_list, vowstarttime];
          vowendtime_list = [vowendtime_list, vowendtime];
          
          
       end
       
       vow=[];
       adrvow=[];
    end
    i=i+1;
    if i>length(out)
        break;
    end
    
end


audioOut = audioIn;

for n=1:vowcount
    
    
    vowtype = vowtype_list(n);
    vowstarttime = vowstarttime_list(n);
    vowendtime = vowendtime_list(n);
    y = audioOut(vowstarttime*fs:vowendtime*fs);
    
   y_len = length(audioOut);
    
    
    if char(vowtype) == "er_ladder" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\er_ladder.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\er_ladder.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\er_ladder.wav');         

        end
        
    elseif char(vowtype) == "a_cat" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\a_cat.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\a_cat.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\a_cat.wav');         
        end
        
     elseif char(vowtype) == "ai_snail" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\ai_snail.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\ai_snail.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\ai_snail.wav');         
        end
        
     elseif char(vowtype) == "air_chair" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\air_chair.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\air_chair.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\air_chair.wav');         
        end
        
     elseif char(vowtype) == "ar_car" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\ar_car.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\ar_car.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\ar_car.wav');         
        end     
        
     elseif char(vowtype) == "aw_law" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\aw_law.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\aw_law.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\aw_law.wav');         
        end
        
     elseif char(vowtype) == "e_egg" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\e_egg.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\e_egg.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\e_egg.wav');         
        end  
        
     elseif char(vowtype) == "ee_bee" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\ee_bee.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\ee_bee.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\ee_bee.wav');         
        end
        
     elseif char(vowtype) == "i_england" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\i_england.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\i_england.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\i_england.wav');         
        end
        
     elseif char(vowtype) == "i_spider" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\i_spider.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\i_spider.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\i_spider.wav');         
        end
        
     elseif char(vowtype) == "o_swan" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\o_swan.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\o_swan.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\o_swan.wav');         
        end
        
     elseif char(vowtype) == "oa_boat" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\oa_boat.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\oa_boat.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\oa_boat.wav');         
        end
        
     elseif char(vowtype) == "oi_coin" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\oi_coin.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\oi_coin.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\oi_coin.wav');         
        end
        
     elseif char(vowtype) == "oo_book" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\oo_book.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\oo_book.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\oo_book.wav');         
        end
        
     elseif char(vowtype) == "oo_moon" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\oo_moon.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\oo_moon.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\oo_moon.wav');         
        end
        
     elseif char(vowtype) == "or_four" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\or_four.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\or_four.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\or_four.wav');         
        end
        
     elseif char(vowtype) == "ow_cow" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\ow_cow.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\ow_cow.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\ow_cow.wav');         
        end
        
     elseif char(vowtype) == "u_mug" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\u_mug.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\u_mug.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\u_mug.wav');         
        end
        
     elseif char(vowtype) == "u_uniform" 
        if accent == "brit"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\british\u_uniform.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\southern\u_uniform.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('C:\Users\Kourosh Vali\Box\eec201\data\accents\midwestern\u_uniform.wav');         
        end
        
        
    end
    
        
           pwr_y =  sum(y.^2)/length(y);
            pwr_y2 = sum(y2.^2)/length(y2);
            y2 = y2 * pwr_y/pwr_y2;
            
            [~,ix,iy] = dtw(y,y2);
            
            y_w = y(ix);
            y2_w = y2(iy);
            
%             audioOut (vowstarttime*fs:vowendtime*fs) = y2_w(1:length(y));
            
            audioOut = [audioOut(1:vowstarttime*fs); y2_w; audioOut(vowendtime*fs:y_len)];
                
            vowstarttime_list =(length(audioOut) - y_len )/fs + vowstarttime_list;
            vowendtime_list =(length(audioOut) - y_len )/fs + vowendtime_list;
    
end







% for i=1:vowcount
%     sound(audioIn(vowstarttime_list(i)*fs:vowendtime_list(i)*fs),fs)
% end
% audioOut = audioIn;

filename = 'out.wav';
audiowrite(filename,audioOut,fs);







