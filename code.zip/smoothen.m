%%%%% smoothern
function [finaladr, vowtype, confvow] = smoothen(adr, vow)


    adr;
    vow;

    vowtype =[];
    finaladr =[];
%     temp = " ";
%     cnt=0;
%     flag=1;
%     for i=1:length(vow)
% 
%         if vow(i) == temp    
%             cnt = cnt +1;
%             if cnt>=2
%                 if flag 
% 
%                     finaladr = [finaladr; i-3;i-2;i-1;i];
%                      flag=0;
%                 else
%                     finaladr = [finaladr; i];
%                 end
%             end
%         else
%             temp =  vow(i);
%             cnt=0;
%             flag = 1;
% 
% 
%         end
%     end


    vowlength = length(adr);
    if vowlength <=3
        finaladr =0;
        vowtype=[];
        confvow=0;
    else
        [vowdom, freq] = mode(categorical(vow));
        
        idx = strfind(vow, char(vowdom));
        confvow = freq/vowlength*100;
            vowtype = vowdom;
%             windowlength=floor(length(adr) * 0.75);
%             
%             dif =(length(adr )- windowlength) /2;
%             
%             finaladr = adr(1+dif:end-dif);
            
            finaladr = adr; 
            
            
    
        
    end




end