
clc;
clearvars -except TrainedClassifierVowCon TrainedClassifierVow TrainedClassifierComp mvowcon svowcon mvow svow mcomp scomp



%%%run before projecttest.m
run train3.m



%%% run before projecttest2.m

% run train1.m
% run train2.m
