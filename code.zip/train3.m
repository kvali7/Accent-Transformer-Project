% clc;
% clear all
clearvars -except TrainedClassifierVowCon TrainedClassifierVow TrainedClassifierComp mvowcon svowcon mvow svow mcomp scomp




%% load files from the dataset
% dataDir = 'C:\Users\Kourosh Vali\Box\eec201\data\vowelcons'; % Path to data directory
% dataDir = 'C:\Users\Kourosh Vali\Box\eec201\data\vowels'; % Path to data directory
dataDir = 'C:\Users\Kourosh Vali\Box\eec201\data\complete'; % Path to data directory


%  overlap in train timeframes
    ov =90;
%     train timeframe length
    tf = 30e-3;
    
    
    
ads = audioDatastore(dataDir, 'IncludeSubfolders', true,...
    'FileExtensions', '.wav',...
    'LabelSource','foldernames');

[trainDatastore, testDatastore]  = splitEachLabel(ads,0.999);

trainDatastore
trainDatastoreCount = countEachLabel(trainDatastore)

% testDatastore
% testDatastorereCount = countEachLabel(testDatastore)

reset(trainDatastore);
[sampleTrain, info] = read(trainDatastore);
sound(sampleTrain,info.SampleRate)
reset(trainDatastore);



%  mono
%  16  Khz sampling
% wav



%% get feaures for training dataset
%%%%%%get all files

lenDataTrain = length(trainDatastore.Files);
features = cell(lenDataTrain,1);

   
% lenDataTrain=1;
for i = 1:lenDataTrain
    
    [dataTrain, infoTrain] = read(trainDatastore);
    
    if size(dataTrain,2) >1
       error ('the sample is stereo convert it to mono') 
    end
    
%     sound(dataTrain,infoTrain.SampleRate)
    

%     infoTrain = struct();
%     infoTrain.Label = 'oa_boat';
%     infoTrain.FileName = 'C:\Users\Kourosh Vali\Box\eec201\data\vowels\oa_boat\her.wav';
%     [dataTrain, infoTrain.SampleRate] = audioread(infoTrain.FileName);


    [features{i}, ~ ]= getMFCCFeatures(dataTrain,infoTrain,ov,tf);
%      [features{i}, mfccl ]= getMFCCFeatures(dataTrain,infoTrain,ov,tf);
%     plot(transpose(rmmissing(mfcc1)))
%     ylabel('Coefficients')
%     xlabel('bins');
%     title('MFCC');
    
end

features = vertcat(features{:});
features = rmmissing(features);

%normalize
featureVectors = features{:,2:14};
m = mean(featureVectors);
s = std(featureVectors);
features{:,2:14} = (featureVectors-m)./s;
head(features)   % Display the first few rows


%% knn training

inputTable = features;
predictorNames = features.Properties.VariableNames;
predictors = inputTable(:, predictorNames(2:14));
response = inputTable.Label;

% Train a classifier

%  5-fold stratified cross validation KNN
[validationAccuracy, confusionMatrix, TrainedClassifier] = trainKnnClassifier(features,20);


fprintf('\nValidation accuracy = %.2f%%\n', validationAccuracy*100);
heatmap(TrainedClassifier.ClassNames, TrainedClassifier.ClassNames, ...
    confusionMatrix);
title(sprintf('Confusion Matrix ov =%d %% valac=%.2f %%',ov,validationAccuracy*100));
xlabel('target')
ylabel('predicted output')



TrainedClassifierComp = TrainedClassifier;
mcomp = m;
scomp = s;