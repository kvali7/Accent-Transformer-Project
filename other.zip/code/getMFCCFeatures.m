function   [featuresTabel, mfcc1] = getMFCCFeatures(dataTrain,infoTrain,ov,tf)




    [~, mfcc1] = calcMFCC(dataTrain,infoTrain.SampleRate,ov,tf);



    filenamesplit = regexp(infoTrain.FileName, filesep, 'split');

    % Output structure
    featurelabel = struct();
    [numsamp,~] = size(mfcc1);
    
    featurelabel.Filename = repmat({filenamesplit{end}},[numsamp, 1]);
    featurelabel.MFCC1 = mfcc1(:,1);
    featurelabel.MFCC2 = mfcc1(:,2);
    featurelabel.MFCC3 = mfcc1(:,3);
    featurelabel.MFCC4 = mfcc1(:,4);
    featurelabel.MFCC5 = mfcc1(:,5);
    featurelabel.MFCC6 = mfcc1(:,6);
    featurelabel.MFCC7 = mfcc1(:,7);
    featurelabel.MFCC8 = mfcc1(:,8);
    featurelabel.MFCC9 = mfcc1(:,9);
    featurelabel.MFCC10 = mfcc1(:,10);
    featurelabel.MFCC11 = mfcc1(:,11);
    featurelabel.MFCC12 = mfcc1(:,12);
    featurelabel.MFCC13 = mfcc1(:,13);
    featurelabel.Label = repmat({char(infoTrain.Label)},[numsamp, 1]);

    featuresTabel = struct2table(featurelabel);






end