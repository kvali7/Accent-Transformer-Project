function [validationAccuracy, confusionMatrix, TrainedClassifier] = trainKnnClassifier(features,k)

     inputTable = features;

%     randomize rows
%      inputTable = inputTable(randperm(size(inputTable,1)) ,:);
     
     
    predictorNames = features.Properties.VariableNames;
    predictors = inputTable(:, predictorNames(2:14));
    response = inputTable.Label;

    % Train a classifier
    % This code specifies all the classifier options and trains the classifier.
    TrainedClassifier = fitcknn(...
        predictors, ...
        response, ...
        'Distance', 'euclidean', ...
        'NumNeighbors', 1, ...
        'DistanceWeight', 'squaredinverse', ...
        'Standardize', false, ...
        'ClassNames', unique(response));

    
    group = (response);
    c = cvpartition(group,'KFold',k); % 5-fold stratified cross validation
    % Perform cross-validation
    partitionedModel = crossval(TrainedClassifier,'CVPartition',c);

    % Compute validation accuracy
    validationAccuracy = 1 - kfoldLoss(partitionedModel, 'LossFun', 'ClassifError');

    % Compute confusion matrix
    validationPredictions = kfoldPredict(partitionedModel);
    confusionMatrix = confusionmat(features.Label, validationPredictions, ...
        'order', TrainedClassifier.ClassNames);
    figure;
    confusionMatrix = diag(sum(confusionMatrix,2))\confusionMatrix*100; % convert to percentages

end