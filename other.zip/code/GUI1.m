function varargout = GUI1(varargin)
% GUI1 MATLAB code for GUI1.fig
%      GUI1, by itself, creates a new GUI1 or raises the existing
%      singleton*.
%
%      H = GUI1 returns the handle to a new GUI1 or the handle to
%      the existing singleton*.
%
%      GUI1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI1.M with the given input arguments.
%
%      GUI1('Property','Value',...) creates a new GUI1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI1

% Last Modified by GUIDE v2.5 17-Mar-2019 17:11:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI1_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI1 is made visible.
function GUI1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI1 (see VARARGIN)

% Choose default command line output for GUI1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure

varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
GUI=guidata(handles.figure1);
%InputFilename = 'Tiger.wav';

%[inspeech, Fs] = audioread(InputFilename); % read the wavefile

%inspeech = speechcoder1(GUI.input); 
plot(handles.axes2,GUI.input);
guidata(handles.figure1,GUI);


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
GUI=guidata(handles.figure1);
%InputFilename = 'Tiger.wav';

%[inspeech, Fs] = audioread(InputFilename); % read the wavefile

soundsc(GUI.input, GUI.freqs);

guidata(handles.figure1,GUI);


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
GUI=guidata(handles.figure1);

[file, path]=uigetfile('*.wav', '*.mp4');
file_in=[path file];
[s_in, GUI.freqs]=audioread(file_in);
s_in=s_in(:,1);
GUI.input=s_in;

guidata(handles.figure1,GUI);


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
%InputFilename = 'Tiger.wav';

%[inspeech, Fs] = audioread(InputFilename); % read the wavefile
GUI=guidata(handles.figure1);
outspeech2 = speechcoder2(GUI.input); 
plot(handles.axes3,outspeech2);
guidata(handles.figure1,GUI);



% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
%InputFilename = 'Tiger.wav';
GUI=guidata(handles.figure1);
%[inspeech, Fs] = audioread(InputFilename); % read the wavefile
outspeech2 = speechcoder2(GUI.input); 
soundsc(outspeech2, GUI.freqs);
guidata(handles.figure1,GUI);


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)

GUI=guidata(handles.figure1);
Fs=8000;
GUI.freqs = Fs;
y=audiorecorder(Fs, 16, 1);
record(y);
uiwait();
stop(y);
myspeech=getaudiodata(y);
myspeech=myspeech(Fs*0.4:end);

audiowrite('originalsound.wav',myspeech,Fs);
InputFilename='originalsound.wav';
[inspeech, Fs] = audioread(InputFilename); % read the wavefile
GUI.input = inspeech;
plot(handles.axes2,GUI.input);
guidata(handles.figure1,GUI);

% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)

uiresume();


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
GUI=guidata(handles.figure1);

% clc;
% clearvars -except TrainedClassifierVowCon TrainedClassifierVow TrainedClassifierComp mvowcon svowcon mvow svow mcomp scomp
run train3.m


accent = "brit";

cons = ["b","d","g","j","l","m","n","ng","r","th_voiced","v","w","y","z","zh"];
vows = ["a_cat","ai_snail", "air_chair", "ar_car" , "aw_law", "e_egg", "ee_bee", "er_ladder", "i_england", "i_spider", "o_swan" , "oa_boat" , "oi_coin" , "oo_book" , "oo_moon" , "or_four" , "ow_cow" , "u_mug" , "u_uniform"];




% filename = 'herscoretoday.wav';


% filenamesplit = regexp(filename, filesep, 'split');


% [audioIn, fs] = audioread(filename);

audioIn=GUI.input;
fs=GUI.freqs;

audioIn = resample(audioIn, 16000,fs);
fs = 16000;
% sound(audioIn,fs)
if size(audioIn,2) >1
    error ('the sample is stereo convert it to mono') 
end


% twoStart = 110e3;
twoStart = 1;
% twoStop = 135e3;
twoStop = length(audioIn);
audioIn = audioIn(twoStart:twoStop);
timeVector = linspace((twoStart/fs),(twoStop/fs),numel(audioIn));
deltatime = (twoStop/fs) - (twoStart/fs);



% pD = audiopluginexample.SpeechPitchDetector;
% [~,pitch] = process(pD,audioIn);

ov =0;
tf = 30e-3;
[~, mfccact] = calcMFCC(audioIn,fs,ov,tf);
numcoef = floor(deltatime/tf);

figure(10);
subplot(2,1,1);
plot(timeVector,audioIn);
xlim([(twoStart/fs) (twoStop/fs)])
ylabel('Amplitude')
xlabel('Time (s)')
% title(char(filenamesplit(end)))

% subplot(3,1,2)
% plot(timeVector,pitch,'*')
% xlim([(twoStart/fs) (twoStop/fs)])
% ylabel('Pitch (Hz)')
% xlabel('Time (s)');
% title('Pitch Contour');


% normalize
% mfcc = rmmissing(mfcc);
% m = mean(rmmissing(mfcc));
% s = std(rmmissing(mfcc));

% mfccact = (mfccact-mvowcon)./svowcon;
% mfccact = (mfccact-mvow)./svow;
mfccact = (mfccact-mcomp)./scomp;


numcoef = floor(deltatime/tf);
figure(10);
subplot(2,1,2)
i=0;
for n=1:numcoef
    
    plot ((1+i)/13:1/13:(13+i)/13,mfccact(n,:))
    i= 13+i;
    hold on
    xlabel('Timeframes and 13 mfcc frequency bins');
    line([i/13 i/13], [-4 ,4])
    
end


title('MFCC features');
ylabel('amplitude normalized')
xlim([0 numcoef])




%  predictedLabels = string(predict(TrainedClassifierVowCon,rmmissing(mfccact)))
%  predictedLabels = string(predict(TrainedClassifierVow,rmmissing(mfccact)))
 predictedLabels = string(predict(TrainedClassifierComp,rmmissing(mfccact)))

totalValidCoefs = size(predictedLabels,1)
[predictedLabel, freq] = mode(categorical(predictedLabels))
match = freq/totalValidCoefs*100





sig = ~isnan(sum(mfccact,2));
out = repmat("-",[length(sig) 1]);
j=1;
for i=1:length(sig)
   if sig(i) 
       if ismember(predictedLabels(j),cons)
            out(i) = "-";
       else
           out(i) = predictedLabels(j);
       end
       
       
       j=j+1;
   end
    
end
out








vowcount =0;
adrvow = [];
vow=[];
i=1;
finaladr_list = [];
vowtype_list=[];
confvow_list=[];
vowstarttime_list = [];
vowendtime_list = [];

while(1)
    while (out(i)~="-")     

        out(i);
        vow = [vow; out(i)];
        adrvow = [adrvow; i];
        i=i+1;

    end
    if ~isempty(vow)
       [finaladr, vowtype, confvow]=smoothen(adrvow, vow);
       
       if finaladr
           
%           the actual identified vowel and its start and end time

          vowcount = vowcount+1;
          vowstarttime =(finaladr(1)-1) * 30e-3;
          vowendtime = (finaladr(end))*30e-3;
          
%           finaladr_list = [finaladr_list, finaladr];
          vowtype_list = [vowtype_list, vowtype];
          confvow_list = [confvow_list, confvow];
          vowstarttime_list = [vowstarttime_list, vowstarttime];
          vowendtime_list = [vowendtime_list, vowendtime];
          
          
       end
       
       vow=[];
       adrvow=[];
    end
    i=i+1;
    if i>length(out)
        break;
    end
    
end


for i=1:vowcount
    sound(audioIn(vowstarttime_list(i)*fs:vowendtime_list(i)*fs),fs)
end


audioOut = audioIn;

for n=1:vowcount
    
    
    vowtype = vowtype_list(n);
    vowstarttime = vowstarttime_list(n);
    vowendtime = vowendtime_list(n);
    y = audioOut(vowstarttime*fs:vowendtime*fs);
    
    
%     sound(y, fs);
%     time=(1:length(y))/(fs);
%     figure(2)
%     subplot(211)
%     plot(time,y);
%     title('Unaccented phoneme')

   out_len = length(audioOut);
    
    
    if char(vowtype) == "er_ladder" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/er_ladder.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/er_ladder.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/er_ladder.wav');         

        end
        
    elseif char(vowtype) == "a_cat" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/a_cat.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/a_cat.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/a_cat.wav');         
        end
        
     elseif char(vowtype) == "ai_snail" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ai_snail.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ai_snail.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ai_snail.wav');         
        end
        
     elseif char(vowtype) == "air_chair" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/air_chair.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/air_chair.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/air_chair.wav');         
        end
        
     elseif char(vowtype) == "ar_car" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ar_car.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ar_car.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ar_car.wav');         
        end     
        
     elseif char(vowtype) == "aw_law" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/aw_law.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/aw_law.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/aw_law.wav');         
        end
        
     elseif char(vowtype) == "e_egg" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/e_egg.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/e_egg.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/e_egg.wav');         
        end  
        
     elseif char(vowtype) == "ee_bee" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ee_bee.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ee_bee.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ee_bee.wav');         
        end
        
     elseif char(vowtype) == "i_england" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/i_england.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/i_england.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/i_england.wav');         
        end
        
     elseif char(vowtype) == "i_spider" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/i_spider.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/i_spider.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/i_spider.wav');         
        end
        
     elseif char(vowtype) == "o_swan" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/o_swan.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/o_swan.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/o_swan.wav');         
        end
        
     elseif char(vowtype) == "oa_boat" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oa_boat.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oa_boat.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oa_boat.wav');         
        end
        
     elseif char(vowtype) == "oi_coin" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oi_coin.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oi_coin.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oi_coin.wav');         
        end
        
     elseif char(vowtype) == "oo_book" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oo_book.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oo_book.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oo_book.wav');         
        end
        
     elseif char(vowtype) == "oo_moon" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oo_moon.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oo_moon.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oo_moon.wav');         
        end
        
     elseif char(vowtype) == "or_four" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/or_four.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/or_four.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/or_four.wav');         
        end
        
     elseif char(vowtype) == "ow_cow" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ow_cow.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ow_cow.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ow_cow.wav');         
        end
        
     elseif char(vowtype) == "u_mug" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/u_mug.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/u_mug.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/u_mug.wav');         
        end
        
     elseif char(vowtype) == "u_uniform" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/u_uniform.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/u_uniform.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/u_uniform.wav');         
        end
        
        
    end
    
%         sound(y2, fs2);
        
        
%            pwr_y =  sum(y.^2)/length(y);
%             pwr_y2 = sum(y2.^2)/length(y2);
%             y2 = y2 * pwr_y/pwr_y2;
%             sound(y2, fs2);

%         time2=(1:length(y2))/(fs2);
%         figure(2)
%         subplot(212)
%         plot(time2,y2);
%         title('accented phoneme')



            [~,ix,iy] = dtw(y,y2);
            
            
%             figure(5)
%             plot(iy,ix);
%             title('dtw plot')



            y_w = y(ix);
            y2_w = y2(iy);
%             sound(y_w,fs); 
%             sound(y2_w,fs);
            
             t = (0:numel(ix)-1)/fs;
            duration = t(end)
            figure(6)
            subplot(2,1,1)
            plot(t,y_w)
            title('Unaccented phoneme warped')
            subplot(2,1,2)
            plot(t,y2_w)
            title('accent phoneme waeped')
            xlabel('Time (seconds)')
            
            
            
            
%             audioOut (vowstarttime*fs:vowendtime*fs) = y2_w(1:length(y));
            
            audioOut = [audioOut(1:vowstarttime*fs); y2_w; audioOut(vowendtime*fs:out_len)];
                
            vowstarttime_list =(length(audioOut) - out_len )/fs + vowstarttime_list;
            vowendtime_list =(length(audioOut) - out_len )/fs + vowendtime_list;
    
end




% sound(audioOut,fs);
GUI.input=audioOut;
GUI.freqs=fs;
filename = 'out.wav';
audiowrite(filename,audioOut,fs);


%InputFilename = 'Tiger.wav';

%[inspeech, Fs] = audioread(InputFilename); % read the wavefile

%inspeech = speechcoder1(GUI.input); 
plot(handles.axes4,GUI.input);


guidata(handles.figure1,GUI);








% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
GUI=guidata(handles.figure1);

% clc;
% clearvars -except TrainedClassifierVowCon TrainedClassifierVow TrainedClassifierComp mvowcon svowcon mvow svow mcomp scomp
run train3.m


accent = "midw";

cons = ["b","d","g","j","l","m","n","ng","r","th_voiced","v","w","y","z","zh"];
vows = ["a_cat","ai_snail", "air_chair", "ar_car" , "aw_law", "e_egg", "ee_bee", "er_ladder", "i_england", "i_spider", "o_swan" , "oa_boat" , "oi_coin" , "oo_book" , "oo_moon" , "or_four" , "ow_cow" , "u_mug" , "u_uniform"];




% filename = 'herscoretoday.wav';


% filenamesplit = regexp(filename, filesep, 'split');


% [audioIn, fs] = audioread(filename);

audioIn=GUI.input;
fs=GUI.freqs;

audioIn = resample(audioIn, 16000,fs);
fs = 16000;
% sound(audioIn,fs)
if size(audioIn,2) >1
    error ('the sample is stereo convert it to mono') 
end


% twoStart = 110e3;
twoStart = 1;
% twoStop = 135e3;
twoStop = length(audioIn);
audioIn = audioIn(twoStart:twoStop);
timeVector = linspace((twoStart/fs),(twoStop/fs),numel(audioIn));
deltatime = (twoStop/fs) - (twoStart/fs);



% pD = audiopluginexample.SpeechPitchDetector;
% [~,pitch] = process(pD,audioIn);

ov =0;
tf = 30e-3;
[~, mfccact] = calcMFCC(audioIn,fs,ov,tf);
numcoef = floor(deltatime/tf);

figure(10);
subplot(2,1,1);
plot(timeVector,audioIn);
xlim([(twoStart/fs) (twoStop/fs)])
ylabel('Amplitude')
xlabel('Time (s)')
% title(char(filenamesplit(end)))

% subplot(3,1,2)
% plot(timeVector,pitch,'*')
% xlim([(twoStart/fs) (twoStop/fs)])
% ylabel('Pitch (Hz)')
% xlabel('Time (s)');
% title('Pitch Contour');


% normalize
% mfcc = rmmissing(mfcc);
% m = mean(rmmissing(mfcc));
% s = std(rmmissing(mfcc));

% mfccact = (mfccact-mvowcon)./svowcon;
% mfccact = (mfccact-mvow)./svow;
mfccact = (mfccact-mcomp)./scomp;


numcoef = floor(deltatime/tf);
figure(10);
subplot(2,1,2)
i=0;
for n=1:numcoef
    
    plot ((1+i)/13:1/13:(13+i)/13,mfccact(n,:))
    i= 13+i;
    hold on
    xlabel('Timeframes and 13 mfcc frequency bins');
    line([i/13 i/13], [-4 ,4])
    
end


title('MFCC features');
ylabel('amplitude normalized')
xlim([0 numcoef])




%  predictedLabels = string(predict(TrainedClassifierVowCon,rmmissing(mfccact)))
%  predictedLabels = string(predict(TrainedClassifierVow,rmmissing(mfccact)))
 predictedLabels = string(predict(TrainedClassifierComp,rmmissing(mfccact)))

totalValidCoefs = size(predictedLabels,1)
[predictedLabel, freq] = mode(categorical(predictedLabels))
match = freq/totalValidCoefs*100





sig = ~isnan(sum(mfccact,2));
out = repmat("-",[length(sig) 1]);
j=1;
for i=1:length(sig)
   if sig(i) 
       if ismember(predictedLabels(j),cons)
            out(i) = "-";
       else
           out(i) = predictedLabels(j);
       end
       
       
       j=j+1;
   end
    
end
out








vowcount =0;
adrvow = [];
vow=[];
i=1;
finaladr_list = [];
vowtype_list=[];
confvow_list=[];
vowstarttime_list = [];
vowendtime_list = [];

while(1)
    while (out(i)~="-")     

        out(i);
        vow = [vow; out(i)];
        adrvow = [adrvow; i];
        i=i+1;

    end
    if ~isempty(vow)
       [finaladr, vowtype, confvow]=smoothen(adrvow, vow);
       
       if finaladr
           
%           the actual identified vowel and its start and end time

          vowcount = vowcount+1;
          vowstarttime =(finaladr(1)-1) * 30e-3;
          vowendtime = (finaladr(end))*30e-3;
          
%           finaladr_list = [finaladr_list, finaladr];
          vowtype_list = [vowtype_list, vowtype];
          confvow_list = [confvow_list, confvow];
          vowstarttime_list = [vowstarttime_list, vowstarttime];
          vowendtime_list = [vowendtime_list, vowendtime];
          
          
       end
       
       vow=[];
       adrvow=[];
    end
    i=i+1;
    if i>length(out)
        break;
    end
    
end


for i=1:vowcount
    sound(audioIn(vowstarttime_list(i)*fs:vowendtime_list(i)*fs),fs)
end


audioOut = audioIn;

for n=1:vowcount
    
    
    vowtype = vowtype_list(n);
    vowstarttime = vowstarttime_list(n);
    vowendtime = vowendtime_list(n);
    y = audioOut(vowstarttime*fs:vowendtime*fs);
    
    
%     sound(y, fs);
%     time=(1:length(y))/(fs);
%     figure(2)
%     subplot(211)
%     plot(time,y);
%     title('Unaccented phoneme')

   out_len = length(audioOut);
    
    
    if char(vowtype) == "er_ladder" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/er_ladder.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/er_ladder.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/er_ladder.wav');         

        end
        
    elseif char(vowtype) == "a_cat" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/a_cat.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/a_cat.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/a_cat.wav');         
        end
        
     elseif char(vowtype) == "ai_snail" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ai_snail.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ai_snail.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ai_snail.wav');         
        end
        
     elseif char(vowtype) == "air_chair" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/air_chair.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/air_chair.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/air_chair.wav');         
        end
        
     elseif char(vowtype) == "ar_car" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ar_car.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ar_car.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ar_car.wav');         
        end     
        
     elseif char(vowtype) == "aw_law" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/aw_law.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/aw_law.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/aw_law.wav');         
        end
        
     elseif char(vowtype) == "e_egg" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/e_egg.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/e_egg.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/e_egg.wav');         
        end  
        
     elseif char(vowtype) == "ee_bee" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ee_bee.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ee_bee.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ee_bee.wav');         
        end
        
     elseif char(vowtype) == "i_england" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/i_england.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/i_england.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/i_england.wav');         
        end
        
     elseif char(vowtype) == "i_spider" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/i_spider.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/i_spider.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/i_spider.wav');         
        end
        
     elseif char(vowtype) == "o_swan" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/o_swan.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/o_swan.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/o_swan.wav');         
        end
        
     elseif char(vowtype) == "oa_boat" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oa_boat.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oa_boat.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oa_boat.wav');         
        end
        
     elseif char(vowtype) == "oi_coin" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oi_coin.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oi_coin.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oi_coin.wav');         
        end
        
     elseif char(vowtype) == "oo_book" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oo_book.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oo_book.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oo_book.wav');         
        end
        
     elseif char(vowtype) == "oo_moon" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oo_moon.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oo_moon.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oo_moon.wav');         
        end
        
     elseif char(vowtype) == "or_four" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/or_four.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/or_four.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/or_four.wav');         
        end
        
     elseif char(vowtype) == "ow_cow" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ow_cow.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ow_cow.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ow_cow.wav');         
        end
        
     elseif char(vowtype) == "u_mug" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/u_mug.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/u_mug.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/u_mug.wav');         
        end
        
     elseif char(vowtype) == "u_uniform" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/u_uniform.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/u_uniform.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/u_uniform.wav');         
        end
        
        
    end
    
%         sound(y2, fs2);
        
        
%            pwr_y =  sum(y.^2)/length(y);
%             pwr_y2 = sum(y2.^2)/length(y2);
%             y2 = y2 * pwr_y/pwr_y2;
%             sound(y2, fs2);

%         time2=(1:length(y2))/(fs2);
%         figure(2)
%         subplot(212)
%         plot(time2,y2);
%         title('accented phoneme')



            [~,ix,iy] = dtw(y,y2);
            
            
%             figure(5)
%             plot(iy,ix);
%             title('dtw plot')



            y_w = y(ix);
            y2_w = y2(iy);
%             sound(y_w,fs); 
%             sound(y2_w,fs);
            
             t = (0:numel(ix)-1)/fs;
            duration = t(end)
            figure(6)
            subplot(2,1,1)
            plot(t,y_w)
            title('Unaccented phoneme warped')
            subplot(2,1,2)
            plot(t,y2_w)
            title('accent phoneme waeped')
            xlabel('Time (seconds)')
            
            
            
            
%             audioOut (vowstarttime*fs:vowendtime*fs) = y2_w(1:length(y));
            
            audioOut = [audioOut(1:vowstarttime*fs); y2_w; audioOut(vowendtime*fs:out_len)];
                
            vowstarttime_list =(length(audioOut) - out_len )/fs + vowstarttime_list;
            vowendtime_list =(length(audioOut) - out_len )/fs + vowendtime_list;
    
end




% sound(audioOut,fs);
GUI.input=audioOut;
GUI.freqs=fs;
filename = 'out.wav';
audiowrite(filename,audioOut,fs);


%InputFilename = 'Tiger.wav';

%[inspeech, Fs] = audioread(InputFilename); % read the wavefile

%inspeech = speechcoder1(GUI.input); 
plot(handles.axes4,GUI.input);


guidata(handles.figure1,GUI);


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
GUI=guidata(handles.figure1);

% clc;
% clearvars -except TrainedClassifierVowCon TrainedClassifierVow TrainedClassifierComp mvowcon svowcon mvow svow mcomp scomp
run train3.m


accent = "sout";

cons = ["b","d","g","j","l","m","n","ng","r","th_voiced","v","w","y","z","zh"];
vows = ["a_cat","ai_snail", "air_chair", "ar_car" , "aw_law", "e_egg", "ee_bee", "er_ladder", "i_england", "i_spider", "o_swan" , "oa_boat" , "oi_coin" , "oo_book" , "oo_moon" , "or_four" , "ow_cow" , "u_mug" , "u_uniform"];




% filename = 'herscoretoday.wav';


% filenamesplit = regexp(filename, filesep, 'split');


% [audioIn, fs] = audioread(filename);

audioIn=GUI.input;
fs=GUI.freqs;

audioIn = resample(audioIn, 16000,fs);
fs = 16000;
% sound(audioIn,fs)
if size(audioIn,2) >1
    error ('the sample is stereo convert it to mono') 
end


% twoStart = 110e3;
twoStart = 1;
% twoStop = 135e3;
twoStop = length(audioIn);
audioIn = audioIn(twoStart:twoStop);
timeVector = linspace((twoStart/fs),(twoStop/fs),numel(audioIn));
deltatime = (twoStop/fs) - (twoStart/fs);



% pD = audiopluginexample.SpeechPitchDetector;
% [~,pitch] = process(pD,audioIn);

ov =0;
tf = 30e-3;
[~, mfccact] = calcMFCC(audioIn,fs,ov,tf);
numcoef = floor(deltatime/tf);

figure(10);
subplot(2,1,1);
plot(timeVector,audioIn);
xlim([(twoStart/fs) (twoStop/fs)])
ylabel('Amplitude')
xlabel('Time (s)')
% title(char(filenamesplit(end)))

% subplot(3,1,2)
% plot(timeVector,pitch,'*')
% xlim([(twoStart/fs) (twoStop/fs)])
% ylabel('Pitch (Hz)')
% xlabel('Time (s)');
% title('Pitch Contour');


% normalize
% mfcc = rmmissing(mfcc);
% m = mean(rmmissing(mfcc));
% s = std(rmmissing(mfcc));

% mfccact = (mfccact-mvowcon)./svowcon;
% mfccact = (mfccact-mvow)./svow;
mfccact = (mfccact-mcomp)./scomp;


numcoef = floor(deltatime/tf);
figure(10);
subplot(2,1,2)
i=0;
for n=1:numcoef
    
    plot ((1+i)/13:1/13:(13+i)/13,mfccact(n,:))
    i= 13+i;
    hold on
    xlabel('Timeframes and 13 mfcc frequency bins');
    line([i/13 i/13], [-4 ,4])
    
end


title('MFCC features');
ylabel('amplitude normalized')
xlim([0 numcoef])




%  predictedLabels = string(predict(TrainedClassifierVowCon,rmmissing(mfccact)))
%  predictedLabels = string(predict(TrainedClassifierVow,rmmissing(mfccact)))
 predictedLabels = string(predict(TrainedClassifierComp,rmmissing(mfccact)))

totalValidCoefs = size(predictedLabels,1)
[predictedLabel, freq] = mode(categorical(predictedLabels))
match = freq/totalValidCoefs*100





sig = ~isnan(sum(mfccact,2));
out = repmat("-",[length(sig) 1]);
j=1;
for i=1:length(sig)
   if sig(i) 
       if ismember(predictedLabels(j),cons)
            out(i) = "-";
       else
           out(i) = predictedLabels(j);
       end
       
       
       j=j+1;
   end
    
end
out








vowcount =0;
adrvow = [];
vow=[];
i=1;
finaladr_list = [];
vowtype_list=[];
confvow_list=[];
vowstarttime_list = [];
vowendtime_list = [];

while(1)
    while (out(i)~="-")     

        out(i);
        vow = [vow; out(i)];
        adrvow = [adrvow; i];
        i=i+1;

    end
    if ~isempty(vow)
       [finaladr, vowtype, confvow]=smoothen(adrvow, vow);
       
       if finaladr
           
%           the actual identified vowel and its start and end time

          vowcount = vowcount+1;
          vowstarttime =(finaladr(1)-1) * 30e-3;
          vowendtime = (finaladr(end))*30e-3;
          
%           finaladr_list = [finaladr_list, finaladr];
          vowtype_list = [vowtype_list, vowtype];
          confvow_list = [confvow_list, confvow];
          vowstarttime_list = [vowstarttime_list, vowstarttime];
          vowendtime_list = [vowendtime_list, vowendtime];
          
          
       end
       
       vow=[];
       adrvow=[];
    end
    i=i+1;
    if i>length(out)
        break;
    end
    
end


for i=1:vowcount
    sound(audioIn(vowstarttime_list(i)*fs:vowendtime_list(i)*fs),fs)
end


audioOut = audioIn;

for n=1:vowcount
    
    
    vowtype = vowtype_list(n);
    vowstarttime = vowstarttime_list(n);
    vowendtime = vowendtime_list(n);
    y = audioOut(vowstarttime*fs:vowendtime*fs);
    
    
%     sound(y, fs);
%     time=(1:length(y))/(fs);
%     figure(2)
%     subplot(211)
%     plot(time,y);
%     title('Unaccented phoneme')

   out_len = length(audioOut);
    
    
    if char(vowtype) == "er_ladder" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/er_ladder.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/er_ladder.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/er_ladder.wav');         

        end
        
    elseif char(vowtype) == "a_cat" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/a_cat.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/a_cat.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/a_cat.wav');         
        end
        
     elseif char(vowtype) == "ai_snail" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ai_snail.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ai_snail.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ai_snail.wav');         
        end
        
     elseif char(vowtype) == "air_chair" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/air_chair.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/air_chair.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/air_chair.wav');         
        end
        
     elseif char(vowtype) == "ar_car" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ar_car.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ar_car.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ar_car.wav');         
        end     
        
     elseif char(vowtype) == "aw_law" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/aw_law.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/aw_law.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/aw_law.wav');         
        end
        
     elseif char(vowtype) == "e_egg" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/e_egg.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/e_egg.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/e_egg.wav');         
        end  
        
     elseif char(vowtype) == "ee_bee" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ee_bee.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ee_bee.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ee_bee.wav');         
        end
        
     elseif char(vowtype) == "i_england" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/i_england.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/i_england.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/i_england.wav');         
        end
        
     elseif char(vowtype) == "i_spider" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/i_spider.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/i_spider.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/i_spider.wav');         
        end
        
     elseif char(vowtype) == "o_swan" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/o_swan.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/o_swan.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/o_swan.wav');         
        end
        
     elseif char(vowtype) == "oa_boat" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oa_boat.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oa_boat.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oa_boat.wav');         
        end
        
     elseif char(vowtype) == "oi_coin" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oi_coin.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oi_coin.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oi_coin.wav');         
        end
        
     elseif char(vowtype) == "oo_book" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oo_book.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oo_book.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oo_book.wav');         
        end
        
     elseif char(vowtype) == "oo_moon" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/oo_moon.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/oo_moon.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/oo_moon.wav');         
        end
        
     elseif char(vowtype) == "or_four" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/or_four.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/or_four.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/or_four.wav');         
        end
        
     elseif char(vowtype) == "ow_cow" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/ow_cow.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/ow_cow.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/ow_cow.wav');         
        end
        
     elseif char(vowtype) == "u_mug" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/u_mug.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/u_mug.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/u_mug.wav');         
        end
        
     elseif char(vowtype) == "u_uniform" 
        if accent == "brit"
            [y2, fs2]=audioread('data/accents/british/u_uniform.wav');         
        end
        if accent == "sout"
            [y2, fs2]=audioread('data/accents/southern/u_uniform.wav');         
        end
        if accent == "midw"
            [y2, fs2]=audioread('data/accents/midwestern/u_uniform.wav');         
        end
        
        
    end
    
%         sound(y2, fs2);
        
        
%            pwr_y =  sum(y.^2)/length(y);
%             pwr_y2 = sum(y2.^2)/length(y2);
%             y2 = y2 * pwr_y/pwr_y2;
%             sound(y2, fs2);

%         time2=(1:length(y2))/(fs2);
%         figure(2)
%         subplot(212)
%         plot(time2,y2);
%         title('accented phoneme')



            [~,ix,iy] = dtw(y,y2);
            
            
%             figure(5)
%             plot(iy,ix);
%             title('dtw plot')



            y_w = y(ix);
            y2_w = y2(iy);
%             sound(y_w,fs); 
%             sound(y2_w,fs);
            
             t = (0:numel(ix)-1)/fs;
            duration = t(end)
            figure(6)
            subplot(2,1,1)
            plot(t,y_w)
            title('Unaccented phoneme warped')
            subplot(2,1,2)
            plot(t,y2_w)
            title('accent phoneme waeped')
            xlabel('Time (seconds)')
            
            
            
            
%             audioOut (vowstarttime*fs:vowendtime*fs) = y2_w(1:length(y));
            
            audioOut = [audioOut(1:vowstarttime*fs); y2_w; audioOut(vowendtime*fs:out_len)];
                
            vowstarttime_list =(length(audioOut) - out_len )/fs + vowstarttime_list;
            vowendtime_list =(length(audioOut) - out_len )/fs + vowendtime_list;
    
end




% sound(audioOut,fs);
GUI.input=audioOut;
GUI.freqs=fs;
filename = 'out.wav';
audiowrite(filename,audioOut,fs);


%InputFilename = 'Tiger.wav';

%[inspeech, Fs] = audioread(InputFilename); % read the wavefile

%inspeech = speechcoder1(GUI.input); 
plot(handles.axes4,GUI.input);


guidata(handles.figure1,GUI);


% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
run train.m
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function axes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes2


% --- Executes during object creation, after setting all properties.
function axes4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes4
