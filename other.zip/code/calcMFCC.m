
function [pitch1, mfcc1] = calcMFCC(x,fs,ov,tf)


pwrThreshold = -50; % Frames with power below this threshold (in dB) are likely to be silence
freqThreshold = 1000; % Frames with zero crossing rate above this threshold (in Hz) are likely to be silence or unvoiced speech

% Audio data will be divided into frames of 30 ms with overlap
% overlappercentage = 75; 
% frameTime = 30e-3;
overlappercentage = ov; 
frameTime = tf;
samplesPerFrame = floor(frameTime*fs);
startIdx = 1;
stopIdx = samplesPerFrame;
increment = floor((1-overlappercentage/100)*samplesPerFrame);
overlapLength = samplesPerFrame - increment;

[pitch1,~] = pitch(x,fs, ...
    'WindowLength',samplesPerFrame, ...
    'OverlapLength',overlapLength);

mfcc1 = mfcc(x,fs,'WindowLength',samplesPerFrame, ...
    'OverlapLength',overlapLength, 'LogEnergy', 'Replace');
numFrames = length(pitch1);
voicing = zeros(numFrames,1);

    for i = 1: numFrames
        
        xFrame = x(startIdx:stopIdx,1); % 30ms frame

        if audiopluginexample.SpeechPitchDetector.isVoicedSpeech(xFrame,fs,... % Determining if the frame is voiced speech
                pwrThreshold,freqThreshold)
            voicing(i) = 1;
        end
        startIdx = startIdx + increment;
        stopIdx = stopIdx + increment;

    
    end
    
pitch1(voicing == 0) = nan;
mfcc1(voicing == 0,:) = nan;


end
